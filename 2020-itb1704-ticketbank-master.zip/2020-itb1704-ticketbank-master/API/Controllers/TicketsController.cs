﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TicketBank_API.Model;

namespace TicketBank_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TicketsController : ControllerBase
    {
        private readonly DataContext _context;

        public TicketsController(DataContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Leia kõik üritused või otsi nime järgi
        /// </summary>
        /// <param name="name">Soovitud ürituse nimi</param>
        /// <returns>1 või kõik üritused</returns>
        // GET: api/Tickets
        [HttpGet("list")]
        public async Task<ActionResult<IEnumerable<Ticket>>> GetTicketList([FromQuery] string name)
        {
            if (name != null)
            {
                var ticketNameList = await _context.TicketList.Where(x => x.TicketName.ToLower().StartsWith(name.ToLower())).ToListAsync();
                return ticketNameList;
            }
            return await _context.TicketList.ToListAsync();
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Ticket>>> GetSpecificTicket([FromQuery] string name)
        {
            if (name != null)
            {
                var ticketNameList = await _context.TicketList.Where(x => x.TicketName.ToLower() == name.ToLower()).ToListAsync();
                return ticketNameList;
            }
            return await _context.TicketList.ToListAsync();
        }

        /// <summary>
        /// Leia konkreetne üritus ID järgi
        /// </summary>
        /// <param name="id">Soovitud ürituse ID</param>
        /// <returns>Valitud üritus</returns>
        // GET: api/Tickets/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Ticket>> GetTicket(int id)
        {
            var ticket = await _context.TicketList.FindAsync(id);

            if (ticket == null)
            {
                return NotFound();
            }

            return ticket;
        }

        /// <summary>
        /// Lae valitud ürituse pilet alla
        /// </summary>
        /// <param name="id">Soovitud ürituse ID</param>
        /// <returns>Kui on olemas, laetakse selle ID-ga ürituse pdf pilet alla</returns>
        [HttpGet("download/{id}")]
        public ActionResult Download(int id)
        {
            var fileToDownload = _context.TicketList.FindAsync(id).Result.PdfTicket;
            if (fileToDownload == null)
            {
                return NotFound();
            }
            var ms = new MemoryStream(fileToDownload);
            return File(ms, "application/pdf", "test.pdf");
        }


        /// <summary>
        /// Uuenda üritust
        /// </summary>
        /// <param name="id">Soovitud ürituse ID</param>
        /// <remarks>
        /// Kirjutab üle kogu ürituse, kui piletit ei valita siis kustutatakse olemasolev pdf pilet.
        /// </remarks>
        /// <returns>Muudetud/ülekirjutatud üritus</returns>
        // PUT: api/Tickets/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTicket(int id, [FromForm]Ticket ticket)
        {
            if (id != ticket.Id)
            {
                return BadRequest();
            }

            if (HttpContext.Request.Form.Files.Any())
            {
                var file = HttpContext.Request.Form.Files[0];
                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    ticket.PdfTicket = stream.ToArray();
                }
            }
            else
            {
                ticket.PdfTicket = ticket.PdfTicket;
            }

            _context.Entry(ticket).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return CreatedAtAction("GetTicket", new { id = ticket.Id }, ticket);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TicketExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// Lisa üritus
        /// </summary>
        /// <remarks>
        /// Üritusel peab olema ID, nimi, asukoht, kuupäev, lisainfo ja võib olla pdf pilet
        /// </remarks>
        /// <returns>Uus üritus</returns>
        // POST: api/Tickets
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Ticket>> PostTicket([FromForm]Ticket ticket, int userID)
        {
            if (_context.TicketList.Select(x => x.Id).Contains(ticket.Id)) return BadRequest();
            if (HttpContext.Request.Form.Files.Any())
            {
                var file = HttpContext.Request.Form.Files[0];
                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    ticket.PdfTicket = stream.ToArray();
                }
            }
            int lastTicketId = _context.TicketList.Max(item => item.Id) + 1;
            ticket.Id = lastTicketId;
            _context.TicketList.Add(ticket);
            _context.UserTickets.Add(
                new UserTicket
                {
                    UserId = userID,
                    TicketId = lastTicketId
                });
            
            await _context.SaveChangesAsync();
            return ticket;
        }

        /// <summary>
        /// Kustuta üritus
        /// </summary>
        /// <param name="id">Soovitud ürituse ID</param>
        /// <response code="200">
        /// Valitud üritus on kustutatud
        /// </response>
        // DELETE: api/Tickets/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Ticket>> DeleteTicket(int id)
        {
            var ticket = await _context.TicketList.FindAsync(id);
            if (ticket == null)
            {
                return NotFound();
            }

            _context.TicketList.Remove(ticket);
            await _context.SaveChangesAsync();

            return ticket;
        }

        private bool TicketExists(int id)
        {
            return _context.TicketList.Any(e => e.Id == id);
        }
    }
}
