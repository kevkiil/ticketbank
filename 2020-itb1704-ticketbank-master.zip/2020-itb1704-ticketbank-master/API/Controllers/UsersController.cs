﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TicketBank_API.Model;
using Microsoft.AspNetCore.Authorization;
using TicketBank_API.Services;
using TicketBank_API.Authentication;

namespace TicketBank_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly DataContext _context;
        private IUserService _userService;

        public UsersController(DataContext context, IUserService userService)
        {
            _context = context;
            _userService = userService;
        }

        [AllowAnonymous]
        [HttpPost("authenticate")]
        public IActionResult Authenticate([FromBody]AuthenticateModel model)
        {
            var user = _userService.Authenticate(model.Username, model.Password);

            if (user == null)
                return BadRequest(new { message = "Username or password is incorrect" });

            return Ok(user);
        }

        /// <summary>
        /// Leia kõik kasutajad
        /// </summary>
        /// <returns>kõik kasutajad</returns>
        // GET: api/Users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUser()
        {
            return await _context.UserList.ToListAsync();
        }

        /// <summary>
        /// Leia konkreetne kasutaja ID järgi
        /// </summary>
        /// <param name="id">Soovitud kasutaja ID</param>
        /// <returns>Valitud kasutaja</returns>
        // GET: api/Users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            var user = await _context.UserList.FindAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            return user;
        }

        // <summary>
        /// Leia konkreetse kasutaja ID järgi temale kuuluvad üritused
        /// </summary>
        /// <param name="id">Soovitud kasutaja ID</param>
        /// <returns>Valitud kasutaja piletid</returns>
        // GET: api/Users/5/tickets
        [HttpGet("{id}/tickets")]
        public async Task<ActionResult<IEnumerable<Ticket>>> GetUserTickets(int id)
        {
            var user = await _context.UserList
                .Include(x => x.UserTickets)
                .ThenInclude(x => x.Ticket)
                .FirstOrDefaultAsync(x => x.Id == id);

            var tickets = user.UserTickets.Select(x => x.Ticket);

            return tickets.ToList();
        }

        // PUT: api/Users/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUser(int id, [FromForm] User user)
        {
            if (id != user.Id)
            {
                return BadRequest();
            }
            if (HttpContext.Request.Form.Files.Any())
            {
                var file = HttpContext.Request.Form.Files[0];
                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    user.ProfilePic = stream.ToArray();
                }
            }
            else
            {
                user.ProfilePic = user.ProfilePic;
            }
            var findUser = await _context.UserList.FindAsync(user.Id);
            string pw = findUser.Password;
            user.Password = pw;

            _context.Entry(user).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return CreatedAtAction("GetUser", new { id = user.Id }, user);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(user.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

        }

        /// <summary>
        /// Lisa kasutaja
        /// </summary>
        /// <remarks>
        /// Kasutajal peab olema ID, nimi, sünnipäev, kasutajanimi
        /// </remarks>
        /// <returns>Uus kasutaja</returns>
        // POST: api/Users
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult<User>> PostUser([FromForm]User user)
        {
            if (UserExistsUsername(user.Username)) return BadRequest();
            if (HttpContext.Request.Form.Files.Any())
            {
                var file = HttpContext.Request.Form.Files[0];
                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    //user.ProfilePic = stream.ToArray();
                }
            }

            _context.UserList.Add(user);
            await _context.SaveChangesAsync();

            return user;

        }

        /// <summary>
        /// Kustuta kasutaja
        /// </summary>
        /// <param name="id">Soovitud kasutaja ID</param>
        /// <response code="200">
        /// Valitud kasutaja on kustutatud
        /// </response>
        // DELETE: api/Users/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<User>> DeleteUser(int id)
        {
            var user = await _context.UserList.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            _context.UserList.Remove(user);
            await _context.SaveChangesAsync();

            return user;
        }

        private bool UserExists(int id)
        {
            return _context.UserList.Any(e => e.Id == id);
        }
        private bool UserExistsUsername(string username)
        {
            return _context.UserList.Any(e => e.Username == username);
        }
    }
}
