﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace TicketBank_API.Model
{
    public class DataContext:DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }
        public DbSet<Ticket> TicketList { get; set; }
        public DbSet<User> UserList { get; set; }
        public DbSet<UserTicket> UserTickets { get; set; }

        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Ticket>().ToTable("TicketList").HasKey(x => x.Id);
            modelBuilder.Entity<User>().ToTable("UserList").HasKey(x => x.Id);
            modelBuilder.Entity<UserTicket>().ToTable("UserTickets").HasKey(key => new {key.UserId, key.TicketId});

            modelBuilder.Entity<User>().Property(p => p.Id).HasIdentityOptions(3);
            modelBuilder.Entity<Ticket>().Property(p => p.Id).HasIdentityOptions(6);
            modelBuilder.Entity<Ticket>().HasData(
                new Ticket
                {
                    Id = 1,
                    TicketName = "Rammstein",
                    EventDate = new DateTime(2020,7,11),
                    EventLocation = "Tallinna Lauluväljak",
                    ExtraInfo = "Ära rattaga tule",
                },
                new Ticket
                {
                    Id = 2,
                    TicketName = "Hotell laibaga",
                    EventDate = new DateTime(2020, 5, 19),
                    EventLocation = "Endla Teater",
                    ExtraInfo = "Pidulik riietus."
                },
                new Ticket
                {
                    Id = 3,
                    TicketName = "Hiiu Folk 2020",
                    EventDate = new DateTime(2020, 7, 16),
                    EventLocation = "Kärdla Villaladu",
                    ExtraInfo = "Õpitoad, loodusmatkad, lastepesad jpm."
                },
                new Ticket
                {
                    Id = 4,
                    TicketName = "Metallica",
                    EventDate = new DateTime(2020, 9, 20),
                    EventLocation = "Alexela Kontserdimaja",
                    ExtraInfo = " METALLICA S&M Tribute Show sümfooniaorkestriga."
                },
                new Ticket
                {
                    Id = 5,
                    TicketName = "Pärnumaa Laulupidu 2020",
                    EventDate = new DateTime(2020, 5, 30),
                    EventLocation = "Pärnu Rannastaadion",
                    ExtraInfo = "Laula kuni elad!"
                }
                );

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Username = "test1",
                    FirstName = "James",
                    LastName = "Maple",
                    Birthday = new DateTime(1987, 5, 22),
                    Password = "test1"
                },
                new User
                {
                    Id = 3,
                    Username = "admin",
                    FirstName = "ADMIN",
                    LastName = "ADMIN",
                    Birthday = new DateTime(1337, 1, 1),
                    Password = "admin"
                },
                new User
                {
                    Id = 2,
                    Username = "test2",
                    FirstName = "Jessica",
                    LastName = "Smith",
                    Birthday = new DateTime(1977, 1, 2),
                    Password = "test2"
                },
                new User
                {
                    Id = 4,
                    Username = "taavi",
                    FirstName = "Taavi",
                    LastName = "Meier",
                    Birthday = new DateTime(1990, 11, 21),
                    Password = "meier",
                    //ProfilePic = File.ReadAllBytes(@"C:\Users\taavi\source\repos\2020-itb1704-ticketbank\Profiilipildid\TrollFace.jpg")
        });
            modelBuilder.Entity<UserTicket>().HasData(
                new UserTicket
                {
                    UserId = 1, 
                    TicketId = 1
                },
                new UserTicket
                {
                    UserId = 1,
                    TicketId = 2
                },
                new UserTicket
                {
                    UserId = 1,
                    TicketId = 3
                },
                new UserTicket
                {
                    UserId = 2,
                    TicketId = 4
                },
                new UserTicket
                {
                    UserId = 2,
                    TicketId = 5
                });

            modelBuilder.UseIdentityColumns();
        }
    }
}
