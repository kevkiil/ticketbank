﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace TicketBank_API.Model
{
    public class Ticket
    {
        public int Id { get; set; }
        public string TicketName { get; set; }
        public string EventLocation { get; set; }
        public string ExtraInfo { get; set; }
        public DateTime? EventDate { get; set; }
        public byte[] PdfTicket { get; set; }
        [JsonIgnore]
        public virtual ICollection<UserTicket> UserTickets { get; set; }
    }
}
