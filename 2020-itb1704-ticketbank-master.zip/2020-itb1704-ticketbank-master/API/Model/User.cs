﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace TicketBank_API.Model
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? Birthday { get; set; }
        public byte[] ProfilePic { get;set; }
        [JsonIgnore]
        public string Password { get; set; }

        public string Token { get; set; }
        [JsonIgnore]
        public virtual ICollection<UserTicket> UserTickets { get; set; }
    }
}
