import * as React from 'react';
import { Route } from 'react-router';
import Layout from './components/Layout';
import Home from './components/Home';
import Counter from './components/Counter';

import './custom.css'
import Tickets from './components/Tickets';
import TicketDetails from './components/TicketDetails';
import TicketAdd from './components/TicketAdd';
import Users from './components/Users';
import UserDetails from './components/UserDetails';
import UserAdd from './components/UserAdd';
import { LoginPage } from './components/LoginPage';

export default () => (
    <Layout>
        <Route exact path='/home' component={Home} />
        <Route exact path='/tickets' component={Tickets} />
        <Route exact path='/users' component={Users} />
        <Route exact path='/users/:UserId' component={UserDetails} />
        <Route exact path='/useradd' component={UserAdd} />
        <Route exact path='/tickets/:ticketId' component={TicketDetails} />
        <Route exact path='/ticketadd' component={TicketAdd} />
        <Route exact path='/' component={LoginPage} />
        <Route path='/counter' component={Counter} />
    </Layout>
);
