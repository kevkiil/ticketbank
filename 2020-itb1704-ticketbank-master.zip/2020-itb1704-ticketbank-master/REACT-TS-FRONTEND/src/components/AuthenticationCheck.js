
function requireAuth(nextState, replace, next) {
    if (!localStorage.getItem('currentUser')) {
      replace({
        pathname: "/loginPage",
        state: {nextPathname: nextState.location.pathname}
      });
    }
    next();
  }


  export default requireAuth