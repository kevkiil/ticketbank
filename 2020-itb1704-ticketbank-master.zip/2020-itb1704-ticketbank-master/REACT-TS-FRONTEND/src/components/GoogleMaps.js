import React, { Component } from 'react'
import { Map, GoogleApiWrapper, Marker  } from 'google-maps-react';
import Geocode from "react-geocode"; 

Geocode.setApiKey('AIzaSyDuf4BX0z9vX2YWBGPvtSxO69kEg1Lnm24');
Geocode.setLanguage("en");
Geocode.setRegion("et");
Geocode.enableDebug();


const mapStyles = {
    width: '30%',
    height: '40%',
  };
  export class MapContainer extends Component {
    constructor(props) {
      super(props);
      this.myRef = React.createRef();
      this.state = {
        loc: {lat: 59.43, lng: 24.75}
      }
      Geocode.fromAddress(props.aadress).then(
        response => {
            const { lat, lng } = response.results[0].geometry.location;
            console.log(lat,lng);
            this.setState({loc: response.results[0].geometry.location})
        },
        error => {
            console.error(error);
        }
        );
    }
    
  
    render() {
      return (
          <Map
            google={this.props.google}
            zoom={10}
            style={mapStyles}
            center={this.state.loc}
          >
            <Marker position={this.state.loc}/>
          </Map>
      );
    }
  }
export default GoogleApiWrapper({
    apiKey: 'AIzaSyDuf4BX0z9vX2YWBGPvtSxO69kEg1Lnm24'
  })(MapContainer);
