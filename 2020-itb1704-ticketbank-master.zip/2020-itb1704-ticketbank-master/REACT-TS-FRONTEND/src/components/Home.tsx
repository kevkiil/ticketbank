import * as React from 'react';
import { connect } from 'react-redux';
import './App.css';
import Search from './Search.js'


const Home = () => (
  <div className = "App">
    <header className = "App-header">
    <h1>TicketBank</h1>
    <div className = "App">
      <Search/> 
    </div>
    </header>
  </div>
);

export default connect()(Home);
