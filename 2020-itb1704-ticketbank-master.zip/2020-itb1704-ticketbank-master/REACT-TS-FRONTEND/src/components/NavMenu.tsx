import * as React from 'react';
import { Collapse, Container, Navbar, NavbarBrand, NavbarToggler, NavItem, NavLink } from 'reactstrap';
import { Link } from 'react-router-dom';
import './NavMenu.css';
import { authenticationService } from './authentication.service';
import { history } from './history'
import { User } from '../store/Users';
import { isNull } from 'util';
import { stringify } from 'querystring';


export default class NavMenu extends React.PureComponent<{}, { isOpen: boolean, currentUser: any }> {
    public state = {
        isOpen: false,
        currentUser: authenticationService.currentUserValue
    };
    
    logout() {
        authenticationService.logout();
        history.push('/');
        window.location.reload(false);
    }
    public render() {
        const { currentUser } = this.state;
        let navItem;
        if (currentUser !== null)
        {
            let currentUserID = "/users/" + JSON.stringify(currentUser.id)
            navItem = <ul className="navbar-nav flex-grow">
                
            <NavItem>
                <NavLink tag={Link} className="text-dark" to="/">Pealeht</NavLink>
            </NavItem>
            <NavItem>
                <NavLink tag={Link} className="text-dark" to="/tickets">Minu piletid</NavLink>
            </NavItem>
            <NavItem>
                <NavLink tag={Link} className="text-dark" to={currentUserID}>Minu profiil</NavLink>
            </NavItem>
            <NavItem>
            <NavLink tag={Link} className="text-dark" to="/">
            <a onClick={this.logout}>Logi välja</a></NavLink>
            </NavItem>
            <NavItem><NavLink className="text-primary">Tere, {currentUser.firstName}!</NavLink></NavItem>
        </ul>;
        }
        const currentUserCheck = JSON.parse(localStorage.getItem('currentUser') || '{}');
        if (currentUserCheck.username === "admin")
        {
            let currentUserID = "/users/" + JSON.stringify(currentUser.id)
            navItem = <ul className="navbar-nav flex-grow">
            <NavItem>
                <NavLink tag={Link} className="text-dark" to="/">Pealeht</NavLink>
            </NavItem>
            <NavItem>
                <NavLink tag={Link} className="text-dark" to="/users">Kasutajad</NavLink>
            </NavItem>
            <NavItem>
                <NavLink tag={Link} className="text-dark" to="/tickets">Minu piletid</NavLink>
            </NavItem>
            <NavItem>
                <NavLink tag={Link} className="text-dark" to={currentUserID}>Minu profiil</NavLink>
            </NavItem>
            <NavItem>
                        <NavLink tag={Link} className="text-dark" to="/">
                        <a onClick={this.logout}>Logi välja</a></NavLink>
                        </NavItem>
        </ul>;
        }
        return (
            
            <header>
                <Navbar className="navbar-expand-sm navbar-toggleable-sm border-bottom box-shadow mb-3" light>
                    <Container>
                        <NavbarBrand tag={Link} to="/">TicketBank</NavbarBrand>
                        <NavbarToggler onClick={this.toggle} className="mr-2"/>
                        <Collapse className="d-sm-inline-flex flex-sm-row-reverse" isOpen={this.state.isOpen} navbar>
                            {navItem}
                        </Collapse>
                    </Container>
                </Navbar>
            </header>
        );
    }

    private toggle = () => {
        this.setState({
            isOpen: !this.state.isOpen
        });
    }
}
