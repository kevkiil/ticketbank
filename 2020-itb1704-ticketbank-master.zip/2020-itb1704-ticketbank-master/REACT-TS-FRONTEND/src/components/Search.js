import React from 'react';
import '../Search.css';
import axios from 'axios';
import Loader from '../loader.gif';
import {apiUrl} from "../config/apiConfig";
import Suggestions from './Suggestions'


class Search extends React.Component {

	constructor( props ) {
		super( props );

		this.state = {
			query: '',
			results: [],
			allTickets: [],
			loading: false,
			AllTicketsLoading: false,
			AllTicketsMessage : '',
			message: '',
			totalResults: 0,
			totalPages: 0,
			currentPageNo: 0,
		};

		this.cancel = '';
	}


	/**
	 * Get the Total Pages count.
	 *
	 * @param total
	 * @param denominator Count of results per page
	 * @return {number}
	 */
	getPageCount = ( total, denominator ) => {
		const divisible	= 0 === total % denominator;
		const valueToBeAdded = divisible ? 0 : 1;
		return Math.floor( total/denominator ) + valueToBeAdded;
	};

	/**
	 * Fetch the search results and update the state with the result.
	 * Also cancels the previous query before making the new one.
	 *
	 * @param {int} updatedPageNo Updated Page No.
	 * @param {String} query Search Query.
	 *
	 */
	fetchSearchResults = ( updatedPageNo = '', query ) => {
		const pageNumber = updatedPageNo ? `&page=${updatedPageNo}` : '';
		const getAllTicektsUrl = `${apiUrl}/api/tickets/list/?name=${query}`;
		const searchUrl = `${apiUrl}/api/tickets/?name=${query}`;
		axios.get( getAllTicektsUrl)
			.then( res => {
				this.setState( {
					allTickets: res.data,
					AllTicketsLoading: false
				} )
			} )
			.catch( error => {
				if ( axios.isCancel(error) || error ) {
					this.setState({
						AllTicketsLoading: false,
						AllTicketsMessage: 'Failed to fetch the data. Please check network'
					})
				}
			} )
		axios.get( searchUrl)
			.then( res => {
				this.setState( {
					results: res.data,
					loading: false
				} )
			} )
			.catch( error => {
				if ( axios.isCancel(error) || error ) {
					this.setState({
						loading: false,
						message: 'Failed to fetch the data. Please check network'
					})
				}
			} )
	};

	handleOnInputChange = ( event ) => {
		const query = event.target.value;
		if ( ! query ) {
			this.setState( { query, allTickets: [], results: [], message: '', totalPages: 0, totalResults: 0 } );
		} else {
			this.setState( { query, loading: true, message: '' }, () => {
				this.fetchSearchResults( 1, query );
			} );
		}
	};

	/**
	 * Fetch results according to the prev or next page requests.
	 *
	 * @param {String} type 'prev' or 'next'
	 */
	handlePageClick = ( type, event ) => {
		event.preventDefault();
		const updatePageNo = 'prev' === type
			? this.state.currentPageNo - 1
			: this.state.currentPageNo + 1;

		if( ! this.state.loading  ) {
			this.setState( { loading: true, message: '' }, () => {
				this.fetchSearchResults( updatePageNo, this.state.query );
			} );
		}
	};

	renderSearchResults = () => {
		const { results } = this.state;

		if ( Object.keys( results ).length && results.length ) {
			return (
				<div className="results-container">
					{ results.map( result => {
						return (
                            <div className="searchResult">
                                <h1>Üritus: {result.ticketName}</h1>
                                <p>Ürituse toimumisaeg: {result.eventDate.substring(0, result.eventDate.length - 9)}</p>
                                <p>Ürituse asukoht: {result.eventLocation}</p>
                                <p>Ürituse lisainfo: {result.extraInfo}</p>
                                <a className="btn btn-primary" href={'/tickets/' + result.id}> Kuva detailid</a>
                            </div>
						)
					} ) }

				</div>
			)
		}
	};

	render() {
		const { query, loading, message, currentPageNo, totalPages } = this.state;

		const showPrevLink = 1 < currentPageNo;
		const showNextLink = totalPages > currentPageNo;

		return (
			<div className="container">
			{/*	Heading*/}
			<h2 className="heading">Otsi piletit!</h2>
			{/* Search Input*/}
			<label className="search-label" htmlFor="search-input">
				<input
					type="text"
					name="query"
					value={ query }
					id="search-input"
					placeholder="Otsi..."
					onChange={this.handleOnInputChange}
				/>
				<Suggestions results={this.state.allTickets} />

				<i className="fa fa-search search-icon" aria-hidden="true"/>
			</label>

			{/*	Error Message*/}
				{message && <p className="message">{ message }</p>}

			{/*	Loader*/}
			<img src={ Loader } className={`search-loading ${ loading ? 'show' : 'hide' }`} alt="loader"/>

			{/*	Result*/}
			{ this.renderSearchResults() }


			</div>
		)
	}
}

export default Search