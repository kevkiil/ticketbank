import React, { useState } from "react";
import {Input, Button,Form } from "reactstrap";
import {Link, Redirect} from 'react-router-dom';
import axios from 'axios';
import {apiUrl} from "../config/apiConfig";
import { createBrowserHistory } from "history";
import { render } from "react-dom";
import '../custom.css'

export const TicketAdd = () => {
  const [ticketNameValue, setTicketName] = useState("");
  const [eventLocationValue, setEventLocation] = useState("");
  const [extraInfoValue, setExtraInfo] = useState("");
  const [eventDateValue, setEventDate] = useState("");
  const [formError, setFormError] = useState("");
  

const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {setTicketName(e.target.value);};
const handleLocationChange = (e: React.ChangeEvent<HTMLInputElement>) => {setEventLocation(e.target.value);};
const handleInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {setExtraInfo(e.target.value);};
const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {setEventDate(e.target.value);};

var formData=new FormData();
let file : File;
const onFileChange = (e: React.ChangeEvent<HTMLInputElement>):any => {
   if ( e.target.files == null ) {
      throw new Error("Error finding e.target.files"); 
   }
   file = e.target.files[0];
 }

const handleAddClick = async () => {setFormError("");
    if (
      ticketNameValue !== "" &&
      eventLocationValue !== "" &&
      extraInfoValue !== "" &&
      eventDateValue !== ""
    ) {
      formData.append("ticketName",ticketNameValue);
      formData.append("eventLocation", eventLocationValue);
      formData.append("extraInfo",extraInfoValue);
      formData.append("eventDate",eventDateValue);
      if(!file){formData.append('pdfTicket','');}
      formData.append('pdfTicket',file);
      console.log(formData);
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      await axios
        .post(`${apiUrl}/api/tickets?userID=${currentUser.id}`, formData, {
          headers: { "Content-Type": 'multipart/form-data' }
        })
        .then(ticketObj => {console.log("Success:", formData);
        });
        console.log(file)
        alert("ÕNNESTUS!");
        window.location.reload();
        window.location.replace("./tickets");
        
    } else {
      setFormError("Kõik väljad peavad olema täidetud!");
    }
  };

  return (
    <Form name="sisestusvorm" style={{margin: "10px 0px"}} onSubmit={e => (e.preventDefault) }>
      <div>
        <h2>Lisa üritus</h2>
        <Input
          className="inputFieldWidth margins"
          type="text"
          onChange={handleNameChange}
          placeholder="Ürituse nimi"
        />
        <Input
          className="inputFieldWidth margins"
          type="text"
          onChange={handleLocationChange}
          placeholder="Ürituse toimumiskoht"
        />
        <Input
          className="inputFieldWidth margins"
          type="datetime-local"
          onChange={handleDateChange}
        />
        <Input
          className="field margins"
          type="textarea"
          onChange={handleInfoChange}
          placeholder="Lisainfo"
        />
        <Input 
          className="inputFieldWidth margins"
          type="file"
          onChange={onFileChange}
          id="input"
        />
        {formError ? <p style={{ color: "red" }}>{formError}</p> : ""}
      </div>
      <Button color="outline-primary" className="primary margins" onClick={handleAddClick}>
        Lisa pilet
      </Button>
      <Link to="./tickets">
        <Button color="outline-primary" className="primary margins" onClick={() => {}}>
          Tagasi
        </Button>
      </Link>
    </Form>
  );
};

export default TicketAdd;