﻿import * as React from 'react';
import {  Table, Input, Button} from "reactstrap";
import { RouteComponentProps } from 'react-router';
import * as TicketStore from '../store/Ticket';
import { connect } from 'react-redux';
import { ApplicationState } from '../store';
import Popup from "reactjs-popup";
import '../custom.css';
import Maps from './GoogleMaps.js' 
import {Link} from 'react-router-dom';
import axios from 'axios';
import {apiUrl} from "../config/apiConfig";

type TicketProps =
    TicketStore.TicketState &
    typeof TicketStore.actionCreators & 
    RouteComponentProps<{ticketId: string}>;
 
    export let modifier:boolean;

    export function exportModifierTrue () {
        modifier=!modifier;
    }

    const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {name = e.target.value};
    const handleLocationChange = (e: React.ChangeEvent<HTMLInputElement>) => {location = e.target.value};
    const handleInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {info = e.target.value};
    const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {date = e.target.value};
    
    var formData=new FormData();
    let name: string, info:string, date:string, location : string;
    let file : File;
    

class Ticket extends React.PureComponent<TicketProps> {

    componentDidMount() {
        this.ensureDataFetched();
    }    
    
    ensureDataFetched(){
        this.props.requestTicket(+this.props.match.params.ticketId);
    }

    onFileChange = (e: React.ChangeEvent<HTMLInputElement>):any => {
        if ( e.target.files == null ) {
           throw new Error("Error finding e.target.files"); 
        }
        file = e.target.files[0];
        formData.append("pdfTicket",file)
      } 
    handleSaveClick = async () => {
        let ticket=this.props.ticket;
        if(ticket===undefined){
            return <h1>Piletit ei leitud</h1>;
        }
        if(name==null || name==undefined) name=ticket.ticketName;
        if(location==null || location==undefined) location = ticket.eventLocation;
        if(info==null || info==undefined) info = ticket.extraInfo;
        if(date==null || date==undefined) date = ticket.eventDate;
        if(file == null && file == undefined) file = ticket.pdfTicket;

        formData.append("id",this.props.match.params.ticketId);
        formData.append("ticketName",name);
        formData.append("eventLocation", location);
        formData.append("extraInfo",info);
        formData.append("eventDate",date);
        if(file != null && file != undefined){
            formData.append("pdfTicket",file);
        }
        

        await axios
            .put(`${apiUrl}/api/tickets/${this.props.match.params.ticketId}`, formData, {
            headers: { "Content-Type": 'multipart/form-data' }
            });
            window.location.reload();   
    };

    handleDownload = () =>{
        if(this.props.ticket===undefined){
            return <h1>Piletit ei leitud</h1>;
        }
        if(this.props.ticket.pdfTicket===null){
            alert("Antud piletile ei ole .pdf faili lisatud");
        }
        let name = this.props.ticket.ticketName
        axios.get(`${apiUrl}/api/tickets/download/${this.props.match.params.ticketId}`,{responseType: 'arraybuffer',
            headers: { "Content-Type": 'application/pdf' }
          }).then((response) => {
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', name+".pdf");
            document.body.appendChild(link);
            link.click();
        });
    }
    modify = () => {
        this.setState({modifier:!modifier})
        modifier=!modifier
    }
    setModifierToFalse = () => {
        modifier=false
    }
    

    public render() {
        let ticket = this.props.ticket;
        if(this.props.isLoading){
            return <span>Laen andmeid...</span>;
        }
        if (ticket === undefined) {
            return <h1>Piletit ei leitud</h1>;
        }
        let nameMod,locationMod,dateMod,extraInfoMod,pdfTicketMod, pdfTicketName, save,muudaTyhistaButton;
        if(modifier==true){
            muudaTyhistaButton=<Button color="outline-primary" className="primary margins" onClick={this.modify}>Tühista</Button>
            save=<Button color="outline-primary" className="primary margins" onClick={this.handleSaveClick}>Salvesta</Button>
            nameMod=<Input type="text" defaultValue={ticket.ticketName} onChange={handleNameChange}/>
            locationMod=<Input type="text" defaultValue={ticket.eventLocation} onChange={handleLocationChange}/>
            dateMod=<Input type="datetime-local" defaultValue={ticket.eventDate} onChange={handleDateChange}/>
            extraInfoMod=<Input type="textarea" defaultValue={ticket.extraInfo} onChange={handleInfoChange}/>
            pdfTicketMod=<Input type="file" onChange={this.onFileChange}/>
            if(ticket.pdfTicket!=null){
                pdfTicketName="Hetkel üles laetud pilet: " +ticket.ticketName+".pdf"
            }    
        }
        else {
            locationMod=ticket.eventLocation
            dateMod=ticket.eventDate
            muudaTyhistaButton=<Button color="outline-primary" className="primary margins" onClick={this.modify}>Muuda</Button>
            extraInfoMod=ticket.extraInfo
            nameMod=ticket.ticketName
        }
        return (
            <React.Fragment>
                <h2>Üritus: </h2><h3><td>{nameMod}</td></h3>
                <Table>
                <div>
                
                    <tbody>
                    
                        <tr>
                            <td><b>Asukoht:</b></td><td>{locationMod}</td>
                            <span className="maps"><Maps aadress={ticket.eventLocation}></Maps>></span> 
                        </tr>                  
                        <tr>
                            <td><b>Kuupäev:</b></td><td> {dateMod}</td>
                        </tr>
                        <tr>
                            <td><b>Lisainfo:</b></td><td>{extraInfoMod}</td>
                        </tr>
                    </tbody>
                    
                    {pdfTicketName}
                    {pdfTicketMod}
                </div>
                </Table>
                {muudaTyhistaButton}
                {save}
                <Button color="outline-primary" className="primary margins" onClick={this.handleDownload}>Lae pilet alla</Button>
                {/* <Popup trigger={<Button color="outline-primary" className="primary margins">Näita kaardil</Button>} position="center center">
                <div><Maps aadress={ticket.eventLocation}></Maps>></div>
                </Popup> */}
                <Link to='../tickets'>
                    <Button color="outline-primary" className="primary margins" onClick={this.setModifierToFalse}>
                        Tagasi
                    </Button>
                </Link>
                <br></br>
            </React.Fragment>
        );
    }
}

export default connect(
    (state: ApplicationState) => state.ticket,
    TicketStore.actionCreators
    )(Ticket as any);