﻿import { FunctionComponent } from 'react';
import * as React from 'react';
import { Table, Button, Pagination, PaginationItem, PaginationLink } from "reactstrap";
import { RouteComponentProps } from 'react-router';
import * as TicketsStore from '../store/Tickets';
import { connect } from 'react-redux';
import { ApplicationState } from '../store';
import {FiArrowDownCircle, FiDelete, FiEdit} from "react-icons/fi";
import {exportModifierTrue} from './TicketDetails';
import DatePicker,{registerLocale} from "react-datepicker";
import 'moment/locale/et';
import enGb from 'date-fns/locale/et';
registerLocale('et', enGb);

type TicketsProps =
    TicketsStore.TicketsState
    & typeof TicketsStore.actionCreators
    & RouteComponentProps<{}>;

class Tickets extends React.PureComponent<TicketsProps> {
    dateString: string[] = []
    dates: Date[] = []
    state = {
        startDate: new Date(),
      };
    handleChange = (date: any) => {
        this.setState({
          startDate: date
        });
      };
    _changeLocation = (ticket: TicketsStore.Ticket) => {
        this.props.history.push(`/tickets/${ticket.id}`);  
    };
    _changeLocatioToModify = (ticket: TicketsStore.Ticket) => {
        exportModifierTrue();
        this.props.history.push(`/tickets/${ticket.id}`); 
    };
    _changeLocationToAddingForm = ()=>{
        this.props.history.push(`./ticketadd`);
    };
    componentDidMount() {
        this.ensureDataFetched();
        
    }    

    private ensureDataFetched(){
        this.props.requestTickets();
    }

    private getDatesForHighlight() {
        let ticket = this.props.tickets;
        this.dateString = ticket.map(x => x.eventDate);
        for (let i = 0; i < this.dateString.length; i++) {
            this.dates.push(new Date(this.dateString[i]));
        }
        this.dates.push(new Date(this.state.startDate))
        return this.dates;
    }
    
    render() {
        return (
            <React.Fragment>
                <div>
                <span className="pealkiri">Minu üritused:</span>
                </div>
                <Table hover>
                    <thead>
                    <tr>
                    <Button color="outline-primary" className="primary margins" onClick={this._changeLocationToAddingForm} >Lisa pilet</Button>
                    </tr>
                    </thead>
                    <div>
                        <tbody>
                        <span className="calendar">
                            <DatePicker  
                                locale="et" 
                                selected={this.state.startDate} 
                                onChange={this.handleChange}
                                includeDates={this.getDatesForHighlight()}
                                forceShowMonthNavigation
                                inline/>
                        </span>
                            {this.props.tickets.map((ticket: TicketsStore.Ticket) =>
                            <TicketDataRow
                                ticket={ticket}
                                key={ticket.id}
                                onClickHandler={() => this._changeLocation(ticket)}
                                onDeleteHandler={() => this.props.deleteTicket(ticket.id)}
                                onDownloadHandler={()=>this.props.downloadTicket(ticket.id, ticket.ticketName, ticket.pdfTicket)}
                                modifyTicket={() => this._changeLocatioToModify(ticket)}
                            />
                            )}
                        </tbody>
                    </div>
                </Table>
                {this.props.isLoading && <span>Laeb andmeid...</span>}
            </React.Fragment>
        );
    }
};

export default connect(
    (state: ApplicationState) => state.tickets,
    TicketsStore.actionCreators
    )(Tickets as any);

type TicketDataProps = { ticket: TicketsStore.Ticket, onClickHandler: () => void, onDeleteHandler:()=>void, onDownloadHandler:()=>void,modifyTicket:()=>void }
const TicketDataRow: FunctionComponent<TicketDataProps> = (props) => (
    <tr onClick={props.onClickHandler}>
        <td className="width">{props.ticket.ticketName}</td>
        <td>
            <Button color="outline-danger"  onClick={(x) => { x.stopPropagation(); props.onDeleteHandler(); }}><FiDelete size="22"/></Button>
            <Button className="btn-tickets-view" color="outline-success" onClick={(x) => { x.stopPropagation(); props.onDownloadHandler(); }}><FiArrowDownCircle size="22"/></Button>
            <Button className="mod-btn-tickets-view" color="outline-warning"  onClick={(x) => { x.stopPropagation(); props.modifyTicket()}}><FiEdit size="22"/></Button>
        </td>
    </tr>
);