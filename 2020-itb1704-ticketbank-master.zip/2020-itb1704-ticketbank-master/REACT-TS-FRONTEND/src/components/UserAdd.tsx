import React, { useState } from "react";
import {Input, Button,Form } from "reactstrap";
import {Link, Redirect} from 'react-router-dom';
import axios from 'axios';
import {apiUrl} from "../config/apiConfig";
import { createBrowserHistory } from "history";
import { render } from "react-dom";
import '../custom.css'
import { AxiosResponse, AxiosError } from 'axios'
const UserAdd = () => {
  const [usernameValue, setusername] = useState("");
  const [firstnameValue, setfirstname] = useState("");
  const [lastnameValue, setlastname] = useState("");
  const [birthdayValue, setbirthday] = useState("");
  const [passwordValue, setpassword] = useState("");
  const [passwordConfirmValue, setConfirmpassword] = useState("");
  const [formError, setFormError] = useState("");

const handleusernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {setusername(e.target.value);};
const handlefirstnameChange = (e: React.ChangeEvent<HTMLInputElement>) => {setfirstname(e.target.value);};
const handlelastnameChange = (e: React.ChangeEvent<HTMLInputElement>) => {setlastname(e.target.value);};
const handlebirthdayChange = (e: React.ChangeEvent<HTMLInputElement>) => {setbirthday(e.target.value);};
const handlepasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {setpassword(e.target.value); if (e.target.value !== passwordConfirmValue) {
  setFormError("Sisestatud paroolid on erinevad!")
} else {
  setFormError("")
}console.log('pw: ' + e.target.value)};
const handlepasswordConfirmChange = (e: React.ChangeEvent<HTMLInputElement>) => {setConfirmpassword(e.target.value); if (passwordValue !== e.target.value) {
  setFormError("Sisestatud paroolid on erinevad!")
} else {
  setFormError("")

} console.log('confirm pw: ' + e.target.value) };

let file : File;
const onFileChange = (e: React.ChangeEvent<HTMLInputElement>):any => {
   if ( e.target.files == null ) {
      throw new Error("Error finding e.target.files"); 
   }
   file = e.target.files[0];
 }
var formData=new FormData();

const handleSubmit = () => {
  const password = passwordValue;
  const confirmPassword = passwordConfirmValue;
  // perform all neccassary validations
  if (password !== confirmPassword) {
      setFormError("Sisestatud paroolid ei ühti!")
  } else {
      setFormError("")
  }
}

const handleAddClick = () => {setFormError("");
const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    if (
      usernameValue !== "" &&
      firstnameValue !== "" &&
      lastnameValue !== "" &&
      birthdayValue !== "" &&
      passwordValue !== ""
    )
     {
       if (passwordValue !== passwordConfirmValue)
       {
         setFormError("Sisestatud paroolid ei ühti!");
       }
       else
       {
        formData.append("username",usernameValue);
        formData.append("firstname", firstnameValue);
        formData.append("lastname",lastnameValue);
        formData.append("birthday",birthdayValue);
        formData.append("password",passwordValue);
        formData.append("image", file);
        console.log(formData);
        axios
          .post(`${apiUrl}/api/users`, formData, {
            headers: { 'Authorization': `Bearer ${currentUser.token}`,
                        "Content-Type": 'multipart/form-data'}
          })
          .then(function(response: AxiosResponse)  {
            // Handle response
            alert("ÕNNESTUS!");
            window.location.reload();
            window.location.replace("./");
          })
          .catch((reason: AxiosError) => {
            if (reason.response!.status === 400) 
            {
              setFormError("Selline kasutajanimi on juba võetud!");
            }
          });
       }
    }
    else 
    {
      setFormError("Kõik väljad peavad olema täidetud!");
    }
  };
  

  return (
    <Form name="sisestusvorm" style={{margin: "10px 0px"}} onSubmit={e => (e.preventDefault) }>
      <div>
        <h2>Registreeri kasutaja</h2>
        <Input
          className="inputFieldWidth margins"
          type="text"
          onChange={handleusernameChange}
          placeholder="Kasutajanimi"
        />
        <Input
          className="inputFieldWidth margins"
          type="text"
          onChange={handlefirstnameChange}
          placeholder="Eesnimi"
        />
        <Input
          className="inputFieldWidth margins"
          type="text"
          onChange={handlelastnameChange}
          placeholder="Perekonnanimi"
        />
        <Input
          className="inputFieldWidth margins"
          type="datetime-local"
          onChange={handlebirthdayChange}
          placeholder="Sünniaeg"
        />
        
        <Input
          id="password"
          className="inputFieldWidth margins"
          type="password"
          onChange={handlepasswordChange}
          placeholder="Salasõna"
        />
        <Input
          id="confirm_password"
          className="inputFieldWidth margins"
          type="password"
          onChange={handlepasswordConfirmChange} 
          placeholder="Korda salasõna"
        />
        <Input
          className="inputFieldWidth margins"
          type="file"
          onChange={onFileChange}
        />
        {formError ? <p style={{ color: "red" }}>{formError}</p> : ""}
      </div>
      <Button id="reg_btn" color="outline-primary" className="primary margins" onClick={handleAddClick}>
        Registreeri
      </Button>
      <Link to="./">
        <Button color="outline-primary" className="primary margins" onClick={() => {}}>
          Tagasi
        </Button>
      </Link>
    </Form>
  );
};

export default UserAdd;