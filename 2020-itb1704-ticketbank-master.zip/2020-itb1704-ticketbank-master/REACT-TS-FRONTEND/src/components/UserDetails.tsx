import * as React from 'react';
import {  Table, Button, Input } from "reactstrap";
import { RouteComponentProps } from 'react-router';
import * as UserStore from '../store/User';
import { connect } from 'react-redux';
import { ApplicationState } from '../store';
import Popup from "reactjs-popup";
import '../custom.css';
import Maps from './GoogleMaps.js' 
import {Link} from 'react-router-dom';
import {apiUrl} from "../config/apiConfig";
import UserTickets from './UserTickets';
import axios from 'axios';

type UserProps =
    UserStore.UserState &
    typeof UserStore.actionCreators & 
    RouteComponentProps<{UserId: string}>;

export let modifier:boolean;

export function exportModifierTrue () {
    modifier=!modifier;
}
const handleFirstNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {firstName= e.target.value};
const handleLastNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {lastName = e.target.value};
const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {birthday = e.target.value};
const onFileChange = (e: React.ChangeEvent<HTMLInputElement>):any => {
    if ( e.target.files == null ) {
       throw new Error("Error finding e.target.files"); 
    }
    file = e.target.files[0];
    formData.append("profilePic",file)
  } 

var formData=new FormData();
let file : File;
let firstName: string, lastName:string, birthday:string, password: string;



class User extends React.PureComponent<UserProps> {

    componentDidMount() {
        this.ensureDataFetched();
    }    
    
    ensureDataFetched(){
        this.props.requestUser(+this.props.match.params.UserId);
        this.setModifierToFalse();
    }



    handleSaveClick = async () => {
        let user=this.props.user;
        if(user===undefined){
            return <h1>Piletit ei leitud</h1>;
        }
        if(firstName==null || firstName==undefined) firstName = user.firstName;
        if(lastName==null || lastName==undefined) lastName = user.lastName;
        if(birthday==null || birthday==undefined) birthday = user.birthday;
        if(file == null && file == undefined) file = user.profilePic;
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
        formData.append("Id",this.props.match.params.UserId);
        formData.append("FirstName",firstName);
        formData.append("LastName", lastName);
        formData.append("Birthday",birthday);
        formData.append("Username", currentUser.username);
        formData.append("Token", currentUser.token)
        if(file != null && file != undefined){
            formData.append("profilePic",file);
        }
        

        await axios
            .put(`${apiUrl}/api/users/${this.props.match.params.UserId}`, formData, {
            headers: { 
                "Content-Type": 'multipart/form-data',
                'Authorization': `Bearer ${currentUser.token}`
         }
            });
            window.location.reload(); 
            
    };

    modify = () => {
        this.setState({modifier:!modifier})
        modifier=!modifier
    }
    setModifierToFalse = () => {
        modifier=false
    }

    public render() {
        let User = this.props.user;
        if(this.props.isLoading){
            return <span>Laen andmeid...</span>;
        }
        if (User === undefined) {
            return <h1>Kasutajat ei leitud</h1>;
        }
        let picture,firstNameMod, lastNameMod, birthdayMod, pictureMod, pictureModText, save, muudaTyhistaButton, parool;
        if(modifier==true){
            muudaTyhistaButton=<Button color="outline-primary" className="primary margins" onClick={this.modify}>Tühista</Button>
            save=<Button color="outline-primary" className="primary margins" onClick={this.handleSaveClick}>Salvesta</Button>
            firstNameMod=<Input type="text" defaultValue={User.firstName} onChange={handleFirstNameChange}/>
            lastNameMod=<Input type="text" defaultValue={User.lastName} onChange={handleLastNameChange}/>
            birthdayMod=<Input type="datetime-local" defaultValue={User.birthday} onChange={handleDateChange}/>
            pictureMod=<Input className="inputFieldWidth margins" type="file" onChange={onFileChange}/>
            pictureModText=<p>Lisa/muuuda profiilipilt:</p>

        }
        else {
            firstNameMod = User.firstName
            lastNameMod = User.lastName
            birthdayMod = User.birthday
            muudaTyhistaButton=<Button color="outline-primary" className="primary margins" onClick={this.modify}>Muuda</Button>
        }
        const data = User.profilePic;
        if(data == null || data==undefined){
            console.log(data);
            picture = <img width='200' src={`https://cdn.dribbble.com/users/1963449/screenshots/5915645/404_not_found.png`} />
        }
        else{
            picture = <img width='200' src={`data:image/jpeg;base64,${data}`} />
        }

        return (
            <React.Fragment>
                <h3>Minu kasutajanimi: {User.username}</h3>
                
                <Table hover>
                <div>
                    <tbody>
                    <span className="profilePicture">{picture}</span>
                        <tr >
                            <td><b>Eesnimi:</b> {firstNameMod}</td>
                        </tr>
                        <tr>
                            <td><b>Perekonnanimi:</b> {lastNameMod}</td>
                        </tr>
                        <tr>
                            <td><b>Sünniaeg:</b> {birthdayMod}</td>
                        </tr>
                    </tbody>
                    {pictureModText}
                    {pictureMod}
                </div>
                </Table>
                {muudaTyhistaButton}
                {save}
                <Link to='../home'>
                    <Button color="outline-primary" className="primary margins">
                        Tagasi
                    </Button>
                </Link>
                <UserTickets id={User.id}></UserTickets>
        
            </React.Fragment>
        );
    }
}

export default connect(
    (state: ApplicationState) => state.user,
    UserStore.actionCreators
    )(User as any);