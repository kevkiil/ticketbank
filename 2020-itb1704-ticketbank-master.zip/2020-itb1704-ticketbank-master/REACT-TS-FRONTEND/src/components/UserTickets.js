import React, { Component } from 'react'
import {apiUrl} from "../config/apiConfig";
import axios from 'axios';
import '../custom.css';
import {Link} from 'react-router-dom';
import {  Table, Button } from "reactstrap";

export class UserTickets extends Component {


    constructor( props ) {
		super( props );

		this.state = {
			results: [],
			loading: false,
			message: ''
		};

		this.cancel = '';
	}

    fetchSearchResults = () => {
		const searchUrl = `${apiUrl}/api/Users/${this.props.id}/tickets`;
		const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');

		axios.get( searchUrl, {
			headers:{
				'Authorization': `Bearer ${currentUser.token}`
			}
		})
			.then( res => {
				this.setState( {
					results: res.data,
					loading: false
				} )
			} )
			.catch( error => {
				if ( axios.isCancel(error) || error ) {
					this.setState({
						loading: false,
						message: 'Failed to fetch the data. Please check network'
					})
				}
			} )
	};

	renderSearchResults = () => {
		const { results } = this.state;

		if ( Object.keys( results ).length && results.length ) {
			return (
				<div className="results-container">
					{ results.map( result => {
						return (
							<Table hover>
                            <tbody>
								<tr>
									<td className="width">
										{result.ticketName}
										
									</td>
									<td>
									<Button color="outline-primary" href={'/tickets/' + result.id}> Kuva detailid</Button>
									</td>
								</tr>
							</tbody>
							</Table>
						)
					} ) }

				</div>
			)
		}
	};
    render() {
        return (
			<div>
				<div className="inner"><button class="primary margins btn btn-outline-primary"  onClick={this.fetchSearchResults}>Näita kasutaja pileteid</button></div>
				{this.renderSearchResults()}
			</div>
            
        )
    }
}

export default UserTickets
