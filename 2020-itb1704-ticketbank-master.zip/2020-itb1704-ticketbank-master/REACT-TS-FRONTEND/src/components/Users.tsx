import { FunctionComponent } from 'react';
import * as React from 'react';
import { Table, Button, Pagination, PaginationItem, PaginationLink } from "reactstrap";
import { RouteComponentProps } from 'react-router';
import * as UsersStore from '../store/Users';
import { connect } from 'react-redux';
import { ApplicationState } from '../store';
import {FiArrowDownCircle, FiDelete, FiEdit} from "react-icons/fi";

type UsersProps =
    UsersStore.UsersState
    & typeof UsersStore.actionCreators
    & RouteComponentProps<{}>;

    class Users extends React.PureComponent<UsersProps> {
        _changeLocation = (User: UsersStore.User) => {
            this.props.history.push(`/users/${User.id}`);    
        };
        _changeLocationToAddingForm = ()=>{
            this.props.history.push(`./useradd`);
        };
    
    public componentDidMount() {
        this.ensureDataFetched();
    }    
    
    private ensureDataFetched(){
        this.props.requestUsers();
    }
        render() {
            return (
                <React.Fragment>
                    <div >
                    <span className="pealkiri">Kasutajad:</span>
                    </div>
                    <Table hover>
                        <thead>
                        <tr>
                        <Button color="outline-primary" className="primary margins" onClick={this._changeLocationToAddingForm} >Lisa kasutaja</Button>
                        </tr>
                        </thead>
                        <div>
                            <tbody>
                                {this.props.Users.map((User: UsersStore.User) =>
                                <UserDataRow
                                    User={User}
                                    key={User.id}
                                    onClickHandler={() => this._changeLocation(User)}
                                    onDeleteHandler={() => this.props.deleteUser(User.id)}
                                />
                                )}
                            </tbody>
                        </div>
                    </Table>
                    {this.props.isLoading && <span>Laeb andmeid...</span>}
                </React.Fragment>
            );
        }
    };
    
    export default connect(
        (state: ApplicationState) => state.users,
        UsersStore.actionCreators
        )(Users as any);
    
    type UserDataProps = { User: UsersStore.User, onClickHandler: () => void, onDeleteHandler:()=>void}
    const UserDataRow: FunctionComponent<UserDataProps> = (props) => (
        <tr onClick={props.onClickHandler}>
            <td className="width">{props.User.username}</td>
            <td>
                <Button color="outline-danger"  onClick={(x) => { x.stopPropagation(); props.onDeleteHandler(); }}><FiDelete size="22"/></Button>
                <Button className="mod-btn-tickets-view" color="outline-warning"  onClick={(x) => { x.stopPropagation()}}><FiEdit size="22"/></Button>
            </td>
        </tr>
    );