import { Action, Reducer } from 'redux';
import { AppThunkAction } from '.';
import { Ticket } from "./Tickets";
import {apiUrl} from "../config/apiConfig";
import { modifier } from '../components/TicketDetails';

export type TicketState = {
    ticket: Ticket|undefined;
    isLoading:boolean;
};

interface ReceiveTicketAction {
    type: "RECEIVE_TICKET";
    ticket: Ticket;
}

interface RequestTicketAction {
    type: "REQUEST_TICKET";
}

type KnownAction = ReceiveTicketAction | RequestTicketAction;

export const actionCreators = {
    requestTicket: (ticketId: number): AppThunkAction<KnownAction> => (
            dispatch, 
            getState
        ) => {
        const appState = getState();
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');

        if(appState && appState.tickets){
            dispatch({type: "REQUEST_TICKET"});
            fetch(`${apiUrl}/api/tickets/${ticketId}`, {
                method: 'GET',
                headers: new Headers({
                    'Authorization': 'Bearer ' + currentUser.token,
                    'Content-Type': 'application/json'
                })
            })
            .then(response=>response.json() as Promise<Ticket>)
            .then(data=>{
                dispatch({type: "RECEIVE_TICKET", ticket: data});
            });
        }
    }
};

const unloadedState: TicketState = {
    ticket : undefined,
    isLoading: false,
};

export const reducer: Reducer<TicketState> = (
        state: TicketState | undefined, 
        incomingAction: Action
    ): TicketState => {
    if (state === undefined) {
        return unloadedState;
    }

    const action = incomingAction as KnownAction;
    switch (action.type) {
        case "REQUEST_TICKET":
            return{
                ticket:state.ticket,
                isLoading: true,
            };     
        case "RECEIVE_TICKET":
            if(action.ticket.id === undefined){
                return{
                    ticket: undefined,
                    isLoading: false,
                };
            }

            return{
                ticket: action.ticket,
                isLoading: false,

            };    
        default:
            return state;
    }
};