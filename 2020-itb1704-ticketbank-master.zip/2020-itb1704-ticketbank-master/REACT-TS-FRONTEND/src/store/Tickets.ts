﻿import { Action, Reducer } from 'redux';
import { AppThunkAction } from '.';
import {apiUrl} from "../config/apiConfig";
import Axios from 'axios';

export type Ticket = {
    id: number;
    ticketName: string;
    eventLocation: string;
    extraInfo: string;
    eventDate: string;
    pdfTicket:File;
}

export type TicketsState = {
    tickets: Ticket[]; 
    isLoading: boolean;
}

interface DeleteTicketAction {
    type: 'DELETE_TICKET';
    ticketId: number;
}

interface RequestTicketsAction{
    type: "REQUEST_TICKETS";
}

interface ReceiveTicketsAction {
    type: "RECEIVE_TICKETS";
    tickets: Ticket[];
}

interface DownloadTicketAction {
    type:"DOWNLOAD_TICKET"
    ticketId: number;
    ticketName: string;
    pdfTicket:File;
}

type KnownAction = DeleteTicketAction | ReceiveTicketsAction | RequestTicketsAction |DownloadTicketAction;


export const actionCreators = {
    deleteTicket: (ticketId: number): AppThunkAction<KnownAction> => (dispatch, getState)=>{
        const appState=getState();
        if(appState && appState.tickets){
            fetch(`${apiUrl}/api/tickets/${ticketId}`,{
                method:"DELETE"
            })
            .then(response=>response.json())
            .then(data=>{
                dispatch({type:"DELETE_TICKET", ticketId:ticketId});
            });
        }
    },
    requestTickets:():AppThunkAction<KnownAction> => (dispatch, getState) => {
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        console.log(currentUser.id)
        const appState = getState();
        if(appState && appState.tickets && currentUser != null){
            dispatch({type:"REQUEST_TICKETS"})
            fetch(`${apiUrl}/api/users/${currentUser.id}/tickets`, {
                method: 'GET',
                headers: new Headers({
                    'Authorization': 'Bearer ' + currentUser.token,
                    'Content-Type': 'application/json'
                })
            })
            .then(response=>response.json() as Promise<Ticket[]>)
            .then(data=>{
                dispatch({type: "RECEIVE_TICKETS", tickets:data});
            })
            ;
        }
        else{
            dispatch({type:"REQUEST_TICKETS"})
            fetch(`${apiUrl}/api/tickets`)
            .then(response=>response.json() as Promise<Ticket[]>)
            .then(data=>{
                dispatch({type: "RECEIVE_TICKETS", tickets:data});
            })
            ;
        }
    },
    downloadTicket: (ticketId: number, ticketName:string, pdfTicket:File): AppThunkAction<KnownAction> => (dispatch, getState)=>{
        const appState=getState();
        if(appState && appState.tickets){
            if(pdfTicket===null){
                alert("Faili ei ole lisatud!");
            }
            Axios.get(`${apiUrl}/api/tickets/download/${ticketId}`,{responseType: 'arraybuffer',
            headers: { "Content-Type": 'application/pdf' }
            }).then((response) => {
                const url = window.URL.createObjectURL(new Blob([response.data]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', ticketName+".pdf");
                document.body.appendChild(link);
                link.click();
            });
        }
    }
};

const unloadedState: TicketsState = {
    tickets: [],
    isLoading:false
};

export const reducer: Reducer<TicketsState> =
    (state: TicketsState | undefined, incomingAction: Action): TicketsState => {
        if (state === undefined) {
            return unloadedState;
        }

        const action = incomingAction as KnownAction;
        switch (action.type) {
            case 'DELETE_TICKET':
                return {
                    tickets: state.tickets.filter(x=>x.id !== action.ticketId),
                    isLoading:false
                };
            case "REQUEST_TICKETS":
                return {
                    tickets: state.tickets,
                    isLoading: true
                };
            case "RECEIVE_TICKETS":
                return{
                    tickets: action.tickets,
                    isLoading:false
                };
            default:
            return state;
        }
    };