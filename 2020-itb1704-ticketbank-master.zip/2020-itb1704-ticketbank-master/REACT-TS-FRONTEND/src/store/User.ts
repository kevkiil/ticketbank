import { Action, Reducer } from 'redux';
import { AppThunkAction } from '.';
import { User as User } from "./Users";
import {apiUrl} from "../config/apiConfig";

export type UserState = {
    user: User|undefined;
    isLoading:boolean;
};

interface ReceiveUserAction {
    type: "RECEIVE_USER";
    user: User;
}

interface RequestUserAction {
    type: "REQUEST_USER";
}

interface RequestUserTicketsAction{
    type: "REQUEST_USERTICKETS";
}

interface ReceiveUserTicketsAction{
    type: "RECEIVE_USERTICKETS";
    user: User;
}

type KnownAction = ReceiveUserAction | RequestUserAction | RequestUserTicketsAction | ReceiveUserTicketsAction;

export const actionCreators = {
    requestUser: (UserId: number): AppThunkAction<KnownAction> => (
            dispatch, 
            getState
        ) => {
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        const appState = getState();
        if(appState && appState.user){
            dispatch({type: "REQUEST_USER" });
            fetch(`${apiUrl}/api/users/${UserId}`, {
                method: 'GET',
                headers: new Headers({
                    'Authorization': 'Bearer ' + currentUser.token,
                    'Content-Type': 'application/json'
                })
            })
            .then(response=>response.json() as Promise<User>)
            .then(data=>{
                dispatch({type: "RECEIVE_USER", user: data});
            });
        }
    }
};

const unloadedState: UserState = {
    user : undefined,
    isLoading: false
};

export const reducer: Reducer<UserState> = (
        state: UserState | undefined, 
        incomingAction: Action
    ): UserState => {
    if (state === undefined) {
        return unloadedState;
    }

    const action = incomingAction as KnownAction;
    switch (action.type) {
        case "REQUEST_USER":
            return{
                user:state.user,
                isLoading: true
            };     
        case "RECEIVE_USER":
            if(action.user.id === undefined){
                return{
                    user: undefined,
                    isLoading: false
                };
            }
            return{
                user: action.user,
                isLoading: false
            };
        case "REQUEST_USERTICKETS":
            return {
                user:state.user,
                isLoading: true
            }
        case "RECEIVE_USERTICKETS":
            if (action.user.id === undefined){
                return{
                    user:undefined,
                    isLoading:false
                }
            }
            return{
                user:action.user,
                isLoading:false
            }
        default:
            return state;
    }
};