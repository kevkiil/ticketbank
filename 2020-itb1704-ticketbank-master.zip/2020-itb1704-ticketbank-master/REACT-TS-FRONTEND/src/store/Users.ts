import { Action, Reducer } from 'redux';
import { AppThunkAction } from '.';
import {apiUrl} from "../config/apiConfig";
import Axios from 'axios';
import { type } from 'os';

export type User = {
    id: number;
    username: string;
    firstName: string;
    lastName: string;
    birthday: string;
    password: string;
    profilePic: File;
}

export type UsersState = {
    Users: User[]
    isLoading: boolean;
}

interface DeleteUserAction {
    type: 'DELETE_USER';
    UserId: number;
}

interface RequestUsersAction{
    type: "REQUEST_USERS";
}

interface ReceiveUsersAction {
    type: "RECEIVE_USERS";
    Users: User[];
}
export type MyObj = {
    id: number;
    username: string;
    firstName: string;
    lastName: string;
    birthday: Date;
    password: string;
    token: string;
}
type KnownAction = DeleteUserAction | ReceiveUsersAction | RequestUsersAction;


export const actionCreators = {
    deleteUser: (UserId: number): AppThunkAction<KnownAction> => (dispatch, getState)=>{
        const appState=getState();
        if(appState && appState.users){
            fetch(`${apiUrl}/api/users/${UserId}`,{
                method:"DELETE"
            })
            .then(response=>response.json())
            .then(data=>{
                dispatch({type:"DELETE_USER", UserId:UserId});
            });
        }
    },
    requestUsers:():AppThunkAction<KnownAction> => (dispatch, getState) => {
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        const appState = getState();
        if(appState && appState.users){
            dispatch({type:"REQUEST_USERS"})
            fetch(`${apiUrl}/api/users`, {
                method: 'GET',
                headers: new Headers({
                    'Authorization': 'Bearer ' + currentUser.token,
                    'Content-Type': 'application/json'
                })
            })
            .then(response=>response.json() as Promise<User[]>)
            .then(data=>{
                dispatch({type: "RECEIVE_USERS", Users:data});
            })
            ;
        }
    }
};

const unloadedState: UsersState = {
    Users: [],
    isLoading:false
};

export const reducer: Reducer<UsersState> =
    (state: UsersState | undefined, incomingAction: Action): UsersState => {
        if (state === undefined) {
            return unloadedState;
        }

        const action = incomingAction as KnownAction;
        switch (action.type) {
            case 'DELETE_USER':
                return {
                    Users: state.Users.filter(x=>x.id !== action.UserId),
                    isLoading:false
                };
            case "REQUEST_USERS":
                return {
                    Users: state.Users,
                    isLoading: true
                };
            case "RECEIVE_USERS":
                return{
                    Users: action.Users,
                    isLoading:false
                };
            default:
            return state;
        }
    };