import * as Counter from './Counter';
import * as Tickets from './Tickets';
import * as Ticket from './Ticket';
import * as Users from './Users'
import * as User from './User'

// The top-level state object
export interface ApplicationState {
    counter: Counter.CounterState | undefined;
    tickets: Tickets.TicketsState | undefined;
    users: Users.UsersState | undefined;
    user: User.UserState | undefined;
    ticket: Ticket.TicketState | undefined;
}

// Whenever an action is dispatched, Redux will update each top-level application state property using
// the reducer with the matching name. It's important that the names match exactly, and that the reducer
// acts on the corresponding ApplicationState property type.
export const reducers = {
    counter: Counter.reducer,
    tickets: Tickets.reducer,
    ticket: Ticket.reducer,
    users: Users.reducer,
    user: User.reducer
};

// This type can be used as a hint on action creators so that its 'dispatch' and 'getState' params are
// correctly typed to match your store.
export interface AppThunkAction<TAction> {
    (dispatch: (action: TAction) => void, getState: () => ApplicationState): void;
}
